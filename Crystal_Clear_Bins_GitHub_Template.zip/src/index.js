import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';

function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>Crystal Clear Bins Booking</h1>
      <p>Choose your frequency and bin service options below.</p>
      <form>
        <label>Name: <input type="text" /></label><br /><br />
        <label>Address: <input type="text" /></label><br /><br />
        <label>Service Frequency:
          <select>
            <option>Weekly</option>
            <option>Bi-Weekly</option>
            <option>Monthly</option>
          </select>
        </label><br /><br />
        <label>Payment Method:
          <select>
            <option>Stripe</option>
            <option>Zelle</option>
            <option>Apple Pay</option>
            <option>Cash App</option>
            <option>Cash (Least Preferred)</option>
          </select>
        </label><br /><br />
        <button type="submit">Book Now</button>
      </form>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
